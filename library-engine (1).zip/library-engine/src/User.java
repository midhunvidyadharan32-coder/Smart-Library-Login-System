import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

/** Abstraction + Inheritance: base class for all member types. */
public abstract class User {
    private final String id, name, passHash;
    private final Map<String, LocalDate> loans = new LinkedHashMap<>(); // isbn -> due date

    protected User(String id, String name, String passHash) {
        this.id = id; this.name = name; this.passHash = passHash;
    }

    // Polymorphic policy: each subclass defines its own rules
    public abstract String role();
    public abstract int maxBooks();
    public abstract int loanDays();
    public abstract double calculateFine(long daysLate);

    public String getId() { return id; }
    public String getName() { return name; }
    public boolean checkPassword(String hash) { return passHash.equals(hash); }
    public Map<String, LocalDate> getLoans() { return Collections.unmodifiableMap(loans); }
    public synchronized void addLoan(String isbn, LocalDate due) { loans.put(isbn, due); }
    public synchronized LocalDate removeLoan(String isbn) { return loans.remove(isbn); }
    public long daysLate(LocalDate due) { return Math.max(0, ChronoUnit.DAYS.between(due, LocalDate.now())); }
}
