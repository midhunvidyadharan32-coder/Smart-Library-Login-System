public class Faculty extends User {
    public Faculty(String id, String name, String hash) { super(id, name, hash); }
    public String role() { return "Faculty"; }
    public int maxBooks() { return 10; }
    public int loanDays() { return 30; }
    public double calculateFine(long late) { return Math.max(0, late - 5) * 0.25; } // 5-day grace
}
