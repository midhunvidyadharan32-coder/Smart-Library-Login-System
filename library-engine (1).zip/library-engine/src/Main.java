import com.sun.net.httpserver.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.*;

public class Main {
    static final ILibraryEngine engine = new LibraryEngine();
    static final Map<String, User> sessions = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/", Main::handle);
        server.start();
        System.out.println("Library Engine running -> http://localhost:8080");
    }

    static void handle(HttpExchange x) throws IOException {
        String p = x.getRequestURI().getPath();
        // CORS: lets the Live Server page (port 5500) call this backend (port 8080)
        Headers h = x.getResponseHeaders();
        h.add("Access-Control-Allow-Origin", "*");
        h.add("Access-Control-Allow-Headers", "Content-Type, Authorization");
        h.add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        if (x.getRequestMethod().equals("OPTIONS")) { x.sendResponseHeaders(204, -1); x.close(); return; }
        try {
            if (p.startsWith("/api/")) api(x, p); else file(x, p);
        } catch (IllegalArgumentException | IllegalStateException e) {
            json(x, 400, "{\"error\":\"" + esc(e.getMessage()) + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            json(x, 500, "{\"error\":\"Server error\"}");
        }
    }

    static void api(HttpExchange x, String p) throws IOException {
        String body = new String(x.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        if (p.equals("/api/register")) {
            User n = engine.register(field(body, "name"), field(body, "password"), field(body, "type"), field(body, "code"));
            json(x, 201, "{\"id\":\"" + n.getId() + "\"}");
            return;
        }
        if (p.equals("/api/login")) {
            User u = engine.login(field(body, "id"), field(body, "password"));
            String token = UUID.randomUUID().toString();
            sessions.put(token, u);
            json(x, 200, "{\"token\":\"" + token + "\"}");
            return;
        }
        String auth = x.getRequestHeaders().getFirst("Authorization");
        User u = auth == null ? null : sessions.get(auth.replace("Bearer ", ""));
        if (u == null) { json(x, 401, "{\"error\":\"Please log in\"}"); return; }

        if (p.equals("/api/me")) json(x, 200, profile(u));
        else if (p.equals("/api/books")) {
            String q = x.getRequestURI().getQuery();
            q = q == null ? "" : URLDecoder.decode(q.replaceFirst("^q=", ""), StandardCharsets.UTF_8);
            StringJoiner sj = new StringJoiner(",", "[", "]");
            for (Book b : engine.search(q))
                sj.add(String.format("{\"isbn\":\"%s\",\"title\":\"%s\",\"author\":\"%s\",\"category\":\"%s\",\"available\":%d,\"total\":%d}",
                        b.getIsbn(), esc(b.getTitle()), esc(b.getAuthor()), esc(b.getCategory()), b.getAvailable(), b.getTotal()));
            json(x, 200, sj.toString());
        } else if (p.startsWith("/api/borrow/")) {
            engine.borrow(u, p.substring(12));
            json(x, 200, "{\"ok\":true}");
        } else if (p.startsWith("/api/return/")) {
            double fine = engine.giveBack(u, p.substring(12));
            json(x, 200, String.format(Locale.US, "{\"fine\":%.2f}", fine));
        } else json(x, 404, "{\"error\":\"Not found\"}");
    }

    static String profile(User u) {
        StringJoiner loans = new StringJoiner(",", "[", "]");
        double total = 0; int overdue = 0;
        for (var e : u.getLoans().entrySet()) {
            long late = u.daysLate(e.getValue());
            double fine = u.calculateFine(late);
            total += fine; if (late > 0) overdue++;
            loans.add(String.format(Locale.US, "{\"isbn\":\"%s\",\"title\":\"%s\",\"due\":\"%s\",\"late\":%d,\"fine\":%.2f}",
                    e.getKey(), esc(engine.find(e.getKey()).getTitle()), e.getValue(), late, fine));
        }
        return String.format(Locale.US, "{\"id\":\"%s\",\"name\":\"%s\",\"role\":\"%s\",\"max\":%d,\"overdue\":%d,\"fines\":%.2f,\"loans\":%s}",
                u.getId(), esc(u.getName()), u.role(), u.maxBooks(), overdue, total, loans);
    }

    static void file(HttpExchange x, String p) throws IOException {
        if (p.equals("/")) p = "/index.html";
        Path f = Path.of("web" + p).normalize();
        if (p.contains("..") || !Files.isRegularFile(f)) { send(x, 404, "text/plain", "Not found".getBytes()); return; }
        String type = p.endsWith(".html") ? "text/html; charset=utf-8" : p.endsWith(".css") ? "text/css" : "application/octet-stream";
        send(x, 200, type, Files.readAllBytes(f));
    }

    static String field(String body, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"").matcher(body);
        return m.find() ? m.group(1) : "";
    }
    static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    static void json(HttpExchange x, int code, String s) throws IOException { send(x, code, "application/json", s.getBytes(StandardCharsets.UTF_8)); }
    static void send(HttpExchange x, int code, String type, byte[] data) throws IOException {
        x.getResponseHeaders().set("Content-Type", type);
        x.sendResponseHeaders(code, data.length);
        try (var o = x.getResponseBody()) { o.write(data); }
    }
}
