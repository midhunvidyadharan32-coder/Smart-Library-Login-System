import java.util.List;

/** Abstraction: the web layer only knows this interface. */
public interface ILibraryEngine {
    User register(String name, String password, String type, String facultyCode);
    User login(String id, String password);
    List<Book> search(String query);
    Book find(String isbn);
    void borrow(User user, String isbn);
    double giveBack(User user, String isbn);
}
