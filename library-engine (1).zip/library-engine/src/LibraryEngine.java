import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LibraryEngine implements ILibraryEngine {
    private static final String FACULTY_CODE = "FACULTY2026";      // needed to sign up as Faculty

    private final Database db = new Database();                    // permanent storage
    private final Map<String, Book> books = new LinkedHashMap<>(); // in-memory collections (fast access)
    private final Map<String, User> users = new ConcurrentHashMap<>();

    public LibraryEngine() {
        if (!db.hasUsers()) seedDemoData();   // first run only
        loadFromDatabase();
    }

    private void seedDemoData() {
        db.saveBook("9780262033848", "Introduction to Algorithms", "Cormen, Leiserson et al.", "Computer Science", 3);
        db.saveBook("9780132350884", "Clean Code", "Robert C. Martin", "Software Engineering", 2);
        db.saveBook("9780134685991", "Effective Java", "Joshua Bloch", "Java", 2);
        db.saveBook("9781491910771", "Head First Java", "Kathy Sierra", "Java", 4);
        db.saveBook("9781119800361", "Operating System Concepts", "Silberschatz", "Computer Science", 2);
        db.saveBook("9780078022159", "Database System Concepts", "Silberschatz", "Databases", 3);
        db.saveBook("9780132126953", "Computer Networks", "Andrew Tanenbaum", "Networking", 1);
        db.saveBook("9780073383095", "Discrete Mathematics", "Kenneth Rosen", "Mathematics", 2);

        db.saveUser("S1001", "Asha Menon", "Student", hash("pass123"));
        db.saveUser("F2001", "Dr. Rao", "Faculty", hash("pass123"));
        // demo loans: one overdue, one on time
        db.saveLoan("S1001", "9780132350884", LocalDate.now().minusDays(8));
        db.saveLoan("S1001", "9780134685991", LocalDate.now().plusDays(6));
    }

    private void loadFromDatabase() {
        for (String[] b : db.loadBooks())
            books.put(b[0], new Book(b[0], b[1], b[2], b[3], Integer.parseInt(b[4])));
        for (String[] u : db.loadUsers())
            users.put(u[0], u[2].equals("Faculty") ? new Faculty(u[0], u[1], u[3]) : new Student(u[0], u[1], u[3]));
        for (String[] l : db.loadLoans()) {            // user_id, isbn, due_date
            User u = users.get(l[0]);
            Book b = books.get(l[1]);
            if (u == null || b == null) continue;
            b.borrowCopy();                            // keeps available copies correct
            u.addLoan(l[1], LocalDate.parse(l[2]));
        }
    }

    public static String hash(String s) {
        try {
            StringBuilder sb = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-256").digest(s.getBytes())) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    // ---------- Sign up ----------
    private String nextId(String prefix, int base) {
        int n = base + 1;
        while (users.containsKey(prefix + n)) n++;
        return prefix + n;
    }

    public synchronized User register(String name, String password, String type, String code) {
        name = name == null ? "" : name.trim();
        if (name.length() < 2) throw new IllegalArgumentException("Please enter your full name");
        if (name.length() > 100) throw new IllegalArgumentException("Name is too long");
        if (password == null || password.length() < 8)
            throw new IllegalArgumentException("Password must be at least 8 characters");
        boolean faculty = "Faculty".equals(type);
        if (faculty && !FACULTY_CODE.equals(code)) throw new IllegalArgumentException("Invalid faculty access code");

        String id = faculty ? nextId("F", 2000) : nextId("S", 1000);
        String h = hash(password);
        User u = faculty ? new Faculty(id, name, h) : new Student(id, name, h);
        db.saveUser(id, name, u.role(), h);
        users.put(id, u);
        return u;
    }

    // ---------- Login & library ----------
    public User login(String id, String pw) {
        String key = id == null ? "" : id.trim().toUpperCase();
        User u = users.get(key);
        boolean ok = u != null && u.checkPassword(hash(pw == null ? "" : pw));
        db.logLogin(key, ok);                          // every attempt is stored
        if (!ok) throw new IllegalArgumentException("Invalid ID or password");
        return u;
    }

    public List<Book> search(String q) {
        String s = q.toLowerCase().trim();
        return books.values().stream().filter(b -> b.getTitle().toLowerCase().contains(s)
                || b.getAuthor().toLowerCase().contains(s) || b.getCategory().toLowerCase().contains(s)).toList();
    }

    public Book find(String isbn) { return books.get(isbn); }

    public synchronized void borrow(User u, String isbn) {
        Book b = books.get(isbn);
        if (b == null) throw new IllegalArgumentException("Book not found");
        if (u.getLoans().containsKey(isbn)) throw new IllegalStateException("You already have this book");
        if (u.getLoans().size() >= u.maxBooks())
            throw new IllegalStateException("Limit reached: " + u.role() + "s can borrow " + u.maxBooks() + " books");
        if (!b.borrowCopy()) throw new IllegalStateException("No copies available right now");
        LocalDate due = LocalDate.now().plusDays(u.loanDays());
        u.addLoan(isbn, due);
        db.saveLoan(u.getId(), isbn, due);
    }

    public synchronized double giveBack(User u, String isbn) {
        LocalDate due = u.removeLoan(isbn);
        if (due == null) throw new IllegalStateException("You have not borrowed this book");
        books.get(isbn).returnCopy();
        db.deleteLoan(u.getId(), isbn);
        return u.calculateFine(u.daysLate(due)); // polymorphic call
    }
}
