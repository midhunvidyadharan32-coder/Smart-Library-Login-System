public class Student extends User {
    public Student(String id, String name, String hash) { super(id, name, hash); }
    public String role() { return "Student"; }
    public int maxBooks() { return 3; }
    public int loanDays() { return 14; }
    public double calculateFine(long late) { return late * 1.50; }
}
