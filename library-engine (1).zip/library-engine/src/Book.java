/** Encapsulation: copy counts can only change through borrowCopy()/returnCopy(). */
public class Book {
    private final String isbn, title, author, category;
    private final int total;
    private int available;

    public Book(String isbn, String title, String author, String category, int copies) {
        this.isbn = isbn; this.title = title; this.author = author; this.category = category;
        this.total = copies; this.available = copies;
    }
    public synchronized boolean borrowCopy() { if (available == 0) return false; available--; return true; }
    public synchronized void returnCopy() { if (available < total) available++; }
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCategory() { return category; }
    public int getTotal() { return total; }
    public synchronized int getAvailable() { return available; }
}
