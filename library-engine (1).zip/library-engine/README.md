# Smart Library Login (Java SE + H2 database + Web UI)

## Folder structure
library-engine/
  lib/   -> put h2-2.2.224.jar here (download link in lib/PUT_H2_JAR_HERE.txt)
  src/   -> Java backend (User, Student, Faculty, Book, ILibraryEngine, LibraryEngine, Database, Main)
  web/   -> index.html, login.html, signup.html, dashboard.html, style.css

## Run
1. Install JDK 17+ (adoptium.net) and VS Code (Extension Pack for Java + Live Server).
2. Download h2-2.2.224.jar into the lib folder.
3. Open src/Main.java and click Run (or in terminal):
     javac -cp "lib/*" -d out src/*.java
     java -cp "out;lib/*" Main
   Wait for: Library Engine running -> http://localhost:8080
4. Right-click web/index.html -> Open with Live Server.

## Demo logins
Student  S1001 / pass123
Faculty  F2001 / pass123
Faculty sign-up access code: FACULTY2026

## Database (H2, file: data/library.mv.db)
Tables: users, books, loans, login_log
View tables (stop backend first):
  java -cp lib/h2-2.2.224.jar org.h2.tools.Console
  URL jdbc:h2:./data/library   user sa   (no password)
Reset everything: stop backend and delete the data folder.
